#' Run the Shiny Application
#'
#' @param options optional, described in ?shiny::shinyApp
#' @import shiny
#' @import ggsci
#' @import ropls
#' @import ggplot2
#' @import ggrepel
#' @import FactoMineR
#' @import ComplexHeatmap
#' @import circlize
#' @import shinybootstrap2
#' @import corrplot
#' @import plotly
#' @import mixOmics
#' @import pmp
#' @import arm
#' @noRd
#' @export
run_app <- function(options = list()) {
  library("ggsci")
  library(ropls)
  library(ggplot2)
  library(ggrepel)
  library(FactoMineR)
  library(ComplexHeatmap)
  library("circlize")
  library(shiny)
  library(shinybootstrap2) 
  library(corrplot)
  library(plotly)
  library(mixOmics)
  library(pmp)
  shiny::shinyApp(ui = app_ui,
                  server = app_server,
                  options = options) 
}
