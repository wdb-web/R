#' The application User-Interface
#' 
#' @param request Internal parameter for `{shiny}`. 
#'     DO NOT REMOVE.
#' @import shiny
#' @import ggsci
#' @import ropls
#' @import ggplot2
#' @import ggrepel
#' @import FactoMineR
#' @import ComplexHeatmap
#' @import circlize
#' @import shinybootstrap2
#' @import corrplot
#' @import plotly
#' @import mixOmics
#' @import pmp
#' @import arm
#' @noRd

library("ggsci")
library(ropls)
library(ggplot2)
library(ggrepel)
library(FactoMineR)
library(ComplexHeatmap)
library("circlize")
library(shiny)
library(shinybootstrap2) 
library(corrplot)
library(plotly)
library(mixOmics)
library(pmp)
my.theme <- theme(axis.text = element_text(colour="black", size=15),
                  text = element_text(size=12),
                  title = element_text(size=16, face="plain", vjust=2),
                  panel.background = element_rect(fill = "white",
                                                  colour = "black", 
                                                  size=0.5),
                  axis.title.x=  element_text(size=16, face="plain", vjust=-0.45),
                  axis.title.y = element_text(size=16, face="plain", vjust=1.2),
                  axis.ticks = element_line(colour="black"),
                  axis.line = element_line(),
                  panel.grid.major = element_line(colour = "gray65"),
                  panel.grid.minor = element_line(colour = "gray85"),
                  legend.title = element_text(size=14, face="plain"),
                  legend.text = element_text(size = 14),
                  legend.key = element_rect(),
                  legend.position=c(.12,.55),
                  strip.text = element_text(size=16),
                  strip.background = element_rect(colour="black", fill="gray90", size=0.5))
IQRdata<-function(x) {
  
  
  Q_range=1;Q_shang=1;Q_xia=1#这个是弄个初始值，否则下面回报错
  colx=ncol(x)
  rowx=nrow(x)
  
  {
    for (i in 1:rowx) {
      q<-x[i,]
      q<-as.matrix(q[q!=0])
      Q_xia[[i]] <- quantile(q, probs = 0.25)
      Q_shang[[i]] <- quantile(q, probs = 0.75)
      Q_range[[i]] <- Q_shang[[i]] - Q_xia[[i]]
      for (j in 1:colx) {
        if(!is.na(x[i,j])){
          if (x[i,j] > (Q_shang[[i]] + 1.5*Q_range[[i]]))
          {
            x[i,j]<-0
          }
          if (x[i,j] < (Q_xia[[i]] - 1.5*Q_range[[i]]))
          {
            x[i,j]<-0
          }
        }}}}
  return(x)
}
s<-function(x,group)
{x.x = t(x)
k.x = matrix(group, ncol = 1)
x.n = cbind(k.x, x.x)
sorted = x.n[order(x.n[, 1]), ]
k = matrix(sorted[, 1], ncol = 1)
g = c()
for (i in 1:nrow(sorted)) {
  if (any(g == sorted[i, 1])) {
    g = g
  }
  else {
    g = matrix(c(g, sorted[i, 1]), ncol = 1)
  }
}
Y = matrix(rep(NA, nrow(sorted)), ncol = 1)
for (i in 1:nrow(sorted)) {
  for (l in 1:2) {
    if (sorted[i, 1] == l) {
      Y[i, ] = 0
    }
    else {
      Y[i, ] = 1
    }
  }
}
X = as.matrix(sorted[, -1], ncol = ncol(sorted) - 1)
nf = 1
T = c()
P = c()
C = c()
W = c()
Tortho = c()
Portho = c()
Wortho = c()
Cortho = c()
for (j in 1:nf) {
  w = (t(X) %*% Y) %*% solve(t(Y) %*% Y)
  w1 = t(w) %*% w
  w2 = abs(sqrt(w1))
  w = w %*% solve(w2)
  t = (X %*% w) %*% solve(t(w) %*% w)
  t1 = t(t) %*% t
  c = t(Y) %*% t %*% solve(t1)
  c1 = t(c) %*% c
  u = Y %*% c %*% solve(c1)
  u1 = t(u) %*% u
  u2 = abs(sqrt(u1))
  p = (t(X) %*% t) %*% solve(t1)
  wortho = p - w
  wortho1 = t(wortho) %*% wortho
  wortho2 = abs(sqrt(abs(wortho1)))
  wortho = wortho %*% solve(wortho2)
  tortho = X %*% wortho %*% solve(t(wortho) %*% wortho)
  tortho1 = t(tortho) %*% tortho
  portho = t(X) %*% tortho %*% solve(tortho1)
  cortho = t(Y) %*% tortho %*% solve(tortho1)
  X = X - tortho %*% t(portho)
  T = matrix(c(T, t))
  P = matrix(c(P, p))
  C = matrix(c(C, c))
  W = matrix(c(W, w))
  Tortho = matrix(c(Tortho, tortho))
  Portho = matrix(c(Portho, portho))
  Wortho = matrix(c(Wortho, wortho))
  Cortho = matrix(c(Cortho, cortho))
}
T = matrix(T, ncol = nf)
T = scale(T,  center = TRUE)

s = as.matrix(sorted[, -1], ncol = ncol(sorted) - 1)
p1 = c()
for (i in 1:ncol(s)) {
  scov = cov(s[, i], T)
  p1 = matrix(c(p1, scov), ncol = 1)
}
pcorr1 = c()
for (i in 1:nrow(p1)) {
  den = apply(T, 2, sd) * sd(s[, i])
  corr1 = p1[i, ]/den
  pcorr1 = matrix(c(pcorr1, corr1), ncol = 1)
}
p1<<-p1
pcorr1<<-pcorr1
ss<-data.frame(p1,pcorr1)
return(ss)
}
paretoscale<-function(z){
  rowmean<-apply(z,1,mean)
  rowsd<-apply(z,1,sd)
  rowsqrtsd<-sqrt(rowsd)
  rv<-sweep(z,1,rowmean,"-")
  rv<-sweep(rv,1,rowsqrtsd,"/")
  return(rv)
}
app_ui<-{ fluidPage(
  sidebarPanel(
    fileInput('file1', '点击一下Browse',
              accept=c('text/csv', 'text/comma-separated-values,text/plain')),
    
    downloadButton("Data", "分析结果
                   (vip,p,FC和标准化的数据)"),
    checkboxInput("header", "第一列代谢物", TRUE),
    
    selectInput(inputId = "del",
                label = "删除异常值",
                choices = c("IQR","NO"),
                selected = "NO"),
    sliderInput(inputId = "del2",
                label = "删除缺失值占比是多少的(80%法则)",
                min=0,
                max=1,
                value = 0.2
    ),
    selectInput(inputId = "bu",
                label = "补缺失值",
                choices = c("最小值的1/2","k最近邻(knn)","随机森林(rf)","NO"),
                selected = "最小值的1/2"),
    selectInput(inputId = "bzh",
                label = "标准化",
                choices = c("总离子流标准化+log化","平均值标准化","NO"),
                selected = "总离子流标准化+log化"),
    selectInput(inputId = "pc",
                label = "pca标准化",
                choices = c("uv格式化","ctr格式化","Par标准化","NO"),
                selected = "uv格式化 "),
    selectInput(inputId = "pls",
                label = "(o)pls标准化",
                choices = c("uv格式化","ctr标准化","Par标准化","standard标准化","NO"),
                selected = "uv格式化"),
    sliderInput(inputId = "plsda",
                label = "(o)pls正交次数(0次即plsda)",
                min=0,
                max=10,
                value = 1
    ),
    numericInput(inputId = "hst",
                 label = "火山图log2FC阈值",
                 value=1),
    numericInput(inputId = "hst2",
                 label = "火山图p阈值",
                 value=0.05),
    numericInput(inputId = "vip",
                 label = "热图vip阈值",
                 value=1),
    uiOutput("fj"),
    uiOutput("tl") ,
    uiOutput("wk") ,
    downloadLink('downloadData', 'Download')
  ),
  
  
  mainPanel(
    fluidRow(
      column(
        width = 12,
        tabsetPanel(type = "tabs",
                    #tabPanel()语句可以使主面板像侧边栏面板一样工作
                    tabPanel("原始数据", br(), DT::dataTableOutput('contents',height = 40
                    )),
                    
                    tabPanel("3DPCA", br(),plotlyOutput("pca",  height = 800, width = "100%")),
                    tabPanel("PCA", br(),plotOutput("mpgPlot", width = 800, height = 800)),
                    tabPanel("OPLS", br(),plotOutput("opls", width = 800, height = 800)),
                    tabPanel("Splot", br(), plotOutput("splot", width = 800, height = 800)),
                    tabPanel("火山图", br(),plotOutput("hst", width = 800, height = 800)),
                    tabPanel("热图", br(), plotOutput("rt", width = 800, height = 800)),
                    tabPanel("相关性", br(), plotOutput("xg", width = 700, height = 800))
        )
        
      )
    ))
)
}
#' Add external Resources to the Application
#' 
#' This function is internally used to add external 
#' resources inside the Shiny application. 
#' 
#' @import shiny
#' @importFrom golem add_resource_path activate_js favicon bundle_resources
#' @noRd
golem_add_external_resources <- function(){
  
  add_resource_path(
    'www', app_sys('app/www')
  )
 
  tags$head(
    favicon(),
    bundle_resources(
      path = app_sys('app/www'),
      app_title = 'shiny2'
    )
  )
}
