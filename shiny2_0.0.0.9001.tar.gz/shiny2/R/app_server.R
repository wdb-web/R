#' The application server-side
#' 
#' @param input,output,session Internal parameters for {shiny}. 
#'     DO NOT REMOVE.
#' @import shiny
#' @import ggsci
#' @import ropls
#' @import ggplot2
#' @import ggrepel
#' @import FactoMineR
#' @import ComplexHeatmap
#' @import circlize
#' @import shinybootstrap2
#' @import corrplot
#' @import plotly
#' @import mixOmics
#' @import pmp
#' @import arm
#' @noRd
library("ggsci")
library(ropls)
library(ggplot2)
library(ggrepel)
library(FactoMineR)
library(ComplexHeatmap)
library("circlize")
library(shiny)
library(shinybootstrap2) 
library(corrplot)
library(plotly)
library(mixOmics)
library(pmp)

app_server <- function(input, output) {
  url1 <- a("富集分析", href="https://www.metaboanalyst.ca/MetaboAnalyst/upload/PathUploadView.xhtml") 
  output$fj <- renderUI({ 
    tagList("把你的差异代谢物上传到:", url1) 
  })
  url2 <- a("kegg通路分析", href="https://www.kegg.jp/kegg/tool/map_pathway2.html") 
  output$tl <- renderUI({ 
    tagList("然后把keggID上传到:", url2) 
  })
  url3 <- a("悟空平台", href="https://www.omicsolution.org/wkomics/passwd/MetaboEnrichKEGG/") 
  output$wk <- renderUI({ 
    tagList("或者直接上传到这个平台:", url3) 
  })
  qcl <- reactive({
    {inFile <- input$file1
    if(input$header) row<-NULL
    else row<-1
    ctr<-(read.csv(inFile$datapath,row.names = row))
    name<-ctr[,1]
    ctr<-ctr[,-1]
    ctr[is.na(ctr)]<-0
    if(input$del=="IQR"){ ctr<-IQRdata(ctr)}
    r1 <- rowSums((ctr==0))/ncol(ctr) >= input$del2
    #r1是缺失值大于...的行
    ctr <- ctr[!r1, ]
    if(input$bu=="最小值的1/2"){v=min(ctr[ctr!=0])/2;ctr[ctr==0]<-v}
    if(input$bu=="k最近邻(knn)"){ 
      ctr[ctr==0]<-NA
      ctr[ctr==""]<-NA
      ctr<-mv_imputation(df=ctr,method="knn")}
    if(input$bu=="随机森林(rf)"){ 
      ctr[ctr==0]<-NA
      ctr[ctr==""]<-NA
      ctr<-mv_imputation(df=ctr,method="rf")}
    if(input$bu=="贝叶斯PCA缺失值估计量(bpca)"){ 
      ctr[ctr==0]<-NA
      ctr[ctr==""]<-NA
      ctr<-mv_imputation(df=ctr,method="bpca")}
    ctr<-as.data.frame(ctr)
    ctr<-as.data.frame(ctr)
    if(input$bzh=="总离子流标准化+log化"){
      ctr<-sweep(ctr,2,apply(ctr, 2, sum),FUN = "/")
    }
    }
    name<-name[!r1]
    ctr<-data.frame(name,ctr)
    return(ctr)
  })
  output$contents <-DT::renderDataTable((ctr<-(read.csv(input$file1$datapath))), filter = 'top', options = list( pageLength = 5, autoWidth = TRUE))
  qclopls <- reactive({
    ctr<-as.data.frame(qcl())
    name<-ctr[,1]
    ctr<-ctr[,-1]
    if(input$bzh=="总离子流标准化+log化"){
      ctr<-log(ctr,2)
    }
    ctr<-as.matrix(ctr)
    d<-"none"
    if(input$pls=="uv格式化"){ctr<-arm::rescale(ctr,"UV")}
    if(input$pls=="ctr格式化"){d<-"center"}
    if(input$pls=="Par标准化"){d<-"pareto"}
    if(input$pls=="standard标准化"){d<-"standard"}
    ctr<-as.data.frame(ctr)
    ctr<-sapply(ctr, as.numeric)
    ctr<-as.data.frame(ctr)
    group<-rep(c(paste("C",1:2)),each=(ncol(ctr)/2))##分组的
    aa <-opls(t(ctr), group,predI = 1, orthoI = input$plsda,crossvalI =ncol(ctr) ,
              scaleC=d)
    oplsda<-aa
    oplsda<<-aa
    return(aa)
  })
  qclp <- reactive({
    ctr<-qcl()[,-1]
    if(input$bzh=="总离子流标准化+log化"){
      ctr<-log(ctr+1,2)
    }
    b<-nrow(ctr)
    ctr<-as.data.frame(ctr)
    padj<-1
    f<-(ncol(ctr)/2)
    for (i in 1:b) {
      padj[i]<-t.test(c(as.numeric(ctr[i,1:f])),c(as.numeric(ctr[i,(1+f):(2*f)])))["p.value"]
    }
    padj<-as.data.frame(padj)
    return(padj)
  })
  qclFC <- reactive({
    ctr<-qcl()[,-1]
    ctr<<-as.data.frame(ctr)
    f<-(ncol(ctr)/2)
    F1<-t(ctr[,1:f]);F2<-t(ctr[,(1+f):(2*f)])
    FC2<-colMeans(F1)/ colMeans(F2)
    return(FC2)
  })
  output$hst <- renderPlot({
    ctr<-(qcl())
    FC<-qclFC()
    log2FC<-log(FC,2)
    padj<-as.numeric(as.data.frame(qclp()))
    data <- data.frame(log2FC=log2FC,padj=padj,qcl()[,1])#和并在一起
    colnames(data)[3]<-"name"
    data$col<-"no"#设置分类，先全部假设为没有no
    data$col[data$padj <= input$hst2 & data$log2FC >= input$hst] <- "up"#如果padj值小于0.05以及log2FC大于等于2，就让数据的col那一列对应的数据no变成up
    data$col[data$padj <= input$hst2 & data$log2FC <= -input$hst] <- "down"#如果padj值小于0.05以及log2FC小于等于-2，就让数据的col那一列对应的数据no变成down
    data<-as.data.frame(data)
    xlim=max(-log2FC,log2FC) #求出xlim的绝对值的最大值，其实是xlim的最大值和-xlim的最大值比较，输出两者最那个
    #下面将画图的过程存在p中
    p<-ggplot(data=data,aes(x=log2FC,y=-1*log10(padj),color = col))+#我有一数据集名字叫data,它的x坐标的数据为log2FC，y坐标数据-1*log10(padj),颜色用我的col数据集
      geom_point()+ #请将它用散点图画出来
      labs(x="log2(FC)",y="-log10(FDR)")+ #它x轴名称为log2(FC)，y轴名称为-log10(FDR)
      ggtitle("Volcano plot")+#它的标题名称为Volcano plot
      scale_color_manual(values =c("#619cff" ,"grey" ,"#f8766d"))+
      geom_hline(aes(yintercept=-1*log10(input$hst2)),colour="black", linetype="dashed") +#加一条y=-1*log10(0.05)的直线，它的颜色为black，线条类型为dashed即虚线
      geom_vline(xintercept=c(-input$hst,input$hst),colour="black", linetype="dashed")+#加一条x=2，和一条x=-2的直线，它的颜色为black，线条类型为dashed即虚线
      theme_bw()+#将背景设置为theme_bw类型，然后再储存在volcano中
      geom_label_repel(data = data[data$col!="no",],#将图的的data数据集的col不等于no和vip大于1的选出来
                       aes(label = name))#将它的名字标上去
    print(p)
  })
  output$pca <- renderPlotly({
    name<-qcl()[,1]
    ctr<-qcl()[,-1]
    ctr<-as.matrix(ctr)
    if(input$pc=="uv格式化"){ctr<-arm::rescale(ctr,"UV")}
    if(input$pc=="ctr格式化"){ctr<-arm::rescale(ctr,"center")}
    if(input$pc=="Par标准化"){ctr<-paretoscale(ctr)}
    ctr<-as.data.frame(ctr)
    group<-rep(c(paste("C",1:2)),each=(ncol(ctr)/2))##分组的
    ppca<-pca(ctr,ncomp =3,center = F)
    ppca[["explained_variance"]]<-ppca[["explained_variance"]]*100
    ppca[["explained_variance"]]<-round(ppca[["explained_variance"]],2)
    pc1_ctr <- paste(ppca[["explained_variance"]][1], "%", sep = "") #PC1的方差贡献率
    pc2_ctr <- paste(ppca[["explained_variance"]][2], "%", sep = "") #PC2的方差贡献率
    pc3_ctr <- paste(ppca[["explained_variance"]][3], "%", sep = "") #PC2的方差贡献率
    a<-ppca[["rotation"]]
    a<-as.data.frame(a)
    PCA1<-ppca
    PCA1<<-PCA1
    fig <- plot_ly(a, x = ~PC1, y = ~PC2, z = ~PC3, color = group, colors = c('#BF382A', '#0C4B8E'))
    fig <- fig %>% add_markers()
    fig <- fig %>% layout(scene = list(xaxis = list(title = pc1_ctr),
                                       yaxis = list(title = pc2_ctr),
                                       zaxis = list(title = pc3_ctr)))
  })
  output$mpgPlot <- renderPlot({
    name<-qcl()[,1]
    ctr<-qcl()[,-1]
    ctr<-as.matrix(ctr)
    if(input$pc=="uv格式化"){ctr<-arm::rescale(ctr,"UV")}
    if(input$pc=="ctr格式化"){ctr<-arm::rescale(ctr,"center")}
    if(input$pc=="Par标准化"){ctr<-paretoscale(ctr)}
    ctr<-as.data.frame(ctr)
    group<-rep(c(paste("C",1:2)),each=(ncol(ctr)/2))##分组的
    pca<-PCA(t(ctr),graph = FALSE)
    PCA2<-pca
    PCA2<<-pca
    dat_1 <- as.data.frame(pca$ind$coord) #dat_1为主成分得分（样本坐标）
    name<-rownames(dat_1)
    dat_1<-cbind(dat_1,name)
    pc1_ctr <- paste(round(pca$eig[1,2], 2), "%", sep = "") #PC1的方差贡献率
    pc2_ctr <- paste(round(pca$eig[2,2], 2), "%", sep = "") #PC2的方差贡献率
    #dat_2 <- as.data.frame(pca$var$coord) #dat_2为主成分载荷（变量坐标）
    ggplot(dat_1, aes(Dim.1, Dim.2,color = group)) + #映射PC1,PC2
      labs(x=paste("PC1", pc1_ctr, sep = " "),
           y=paste("PC2", pc2_ctr, sep = " "), color=group)+ 
      geom_point(alpha=.7, size=10) + theme_classic() + theme(axis.text.y=element_text(family="SourceHanSerifCN-Bold", face="bold", size=20),axis.text.x=element_text(family="SourceHanSerifCN-Bold", face="bold", size=20),text=element_text(family="SourceHanSerifCN-Bold", face="bold", size=20))+
      stat_ellipse( geom = "polygon", alpha = 0.1, level = 0.95, 
                    col="black",size=1)+#加置信椭圆
      geom_text_repel(data = dat_1 ,
                      aes(label = name),
                      size = 5,
                      check_overlap = TRUE,
                      colour = "red",
                      box.padding = unit(0.2, "lines"),
                      point.padding = unit(0.1, "lines"), segment.color = "black", show.legend = FALSE )
  })
  output$opls <- renderPlot({
    ctr<-as.data.frame(qcl())
    name<-ctr[,1]
    ctr<-ctr[,-1]
    if(input$bzh=="总离子流标准化+log化"){
      ctr<-log(ctr,2)
    }
    ctr<-as.matrix(ctr)
    d<-"none"
    if(input$pls=="uv格式化"){ctr<-arm::rescale(ctr,"UV")}
    if(input$pls=="ctr格式化"){d<-"center"}
    if(input$pls=="Par标准化"){d<-"pareto"}
    if(input$pls=="standard标准化"){d<-"standard"}
    ctr<-as.data.frame(ctr)
    ctr<-sapply(ctr, as.numeric)
    ctr<-as.data.frame(ctr)
    group<-rep(c(paste("C",1:2)),each=(ncol(ctr)/2))##分组的
    aa <-opls(t(ctr), group,predI = 1, orthoI = input$plsda,crossvalI =ncol(ctr) ,
              scaleC=d)
     }) 
  output$splot<- renderPlot({
    ctr<-as.data.frame(qcl())
    name<-ctr[,1]
    ctr<-ctr[,-1]
    if(input$bzh=="总离子流标准化+log化"){
      ctr<-log(ctr,2)
    }
    ctr<-as.matrix(ctr)
    if(input$pls=="uv格式化"){ctr<-arm::rescale(ctr,"UV")}
    if(input$pls=="ctr格式化"){ctr<-scale(ctr,center = TRUE,scale = FALSE)}
    if(input$pls=="Par标准化"){ctr<-paretoscale(ctr)}
    ctr<-as.data.frame(ctr)
    group<-rep(c(1:2),each=(ncol(ctr)/2))##分组的
    splot<-data.frame(s(t(qclopls()@suppLs[["xModelMN"]]),group),qclopls()@vipVn,name)
    colnames(splot)<-c("p1","pcorr1","VIP","name")
    splot$col="no"
    splot$col[(splot$VIP>1)]<-"good"
    splot$group="no"
    splot<-(splot[order(splot$p1),])
    s<-splot[is.na(splot$name)|(splot$name!=""),]
    p<-splot[!is.na(splot$name)&(splot$name==""),]
    s$group[1:6]<-"down"
    s$group[(length(s$col)-5):length(s$col)]<-"up"
    splot<-rbind(s,p)
    
    ggplot(data=splot)+geom_point(aes(p1,pcorr1,col=col))+
      scale_color_aaas()+ggsci::scale_fill_tron()+my.theme+
      geom_label_repel(data = splot[splot$group!="no",],#将图的的data数据集的col不等于no和vip大于1的选出来
                       aes(x = p1,y=pcorr1,label = name))
  }) 
  da <- reactive({
    dat<-data.frame(qclopls()@vipVn,as.numeric(as.data.frame(qclp())) ,qclFC(),qcl())
    colnames(dat)<-c("VIP","p","FC",colnames(qcl()))
    x<-as.data.frame(dat)
    dat<<-x
    return(x)
  })
  output$Data <- downloadHandler(
    filename = function() {
      paste(input$file1)
    },
    content = function(file) {
      dat<-data.frame(qclopls()@vipVn,as.numeric(as.data.frame(qclp())) ,qclFC(),qcl())
      colnames(dat)<-c("VIP","p","FC",colnames(qcl()))
      write.csv(dat, file)
    }
  )
  output$downloadData <- downloadHandler(
    filename = function() {
      paste('分析结果-', Sys.Date(), '.csv', sep='')
    },
    content = function(con) {
      write.csv(da() , con)
    }
  )
  
  output$rt <- renderPlot({
    dat<-data.frame(qclopls()@vipVn,as.numeric(as.data.frame(qclp())) ,qclFC(),qcl())
    dat<- na.omit(dat)
    
    colnames(dat)<-c("VIP","p","FC","name",colnames(qcl()[,-1]))
    dat<<-as.data.frame(dat)
    x<-as.data.frame(dat)
    x$FC<-log(x$FC,2)
    x<-x[((x$VIP>input$vip)&(x$FC>input$hst|x$FC<(-(input$hst)))&(x$p<input$hst2)&(x$name!="")),]
    row.names(x)<-x$name
    x<-x[,5:ncol(x)]
    group<-rep(c(paste("C",1:2)),each=(ncol(qcl()[,-1])/2))##分组的
    f<-(ncol(ctr)/2)
    FC<-colMeans(t(x[,1:f]));
    FC1<-colMeans(t(x[,(1+f):(2*f)]))
    FC<-data.frame(FC,FC1)
    FC<-as.matrix(FC)
    col=colorRamp2(c(-2,0,2),c("green","white","red"))
    x<-t(as.matrix(scale(t(x))))
    ha = rowAnnotation(foo = anno_lines(FC,  width = unit(2, "cm"),
                                        gp = gpar(col = c(5,4)), 
                                        add_points = TRUE, 
                                        pt_gp = gpar(col = c(5,4)),
                                        pch = c(1,16)))
    d<-Heatmap(x,
               top_annotation = HeatmapAnnotation(group=anno_block(gp = gpar(fill = c(5,4)),
                                                                   labels = c("C", "H"), 
                                                                   labels_gp = gpar(col = "white", fontsize = 10))),
               left_annotation = ha,col =col,column_split = factor(rep(c(paste("C",1:2)),each=(ncol(qcl()[,-1])/2))),
               column_names_gp = gpar(col = rep(c(5,4)),each=(ncol(qcl()[,-1])/2),fontsize=20))
    
    print(d)
    output$xg <- renderPlot({
      dat<-data.frame(qclopls()@vipVn,as.numeric(as.data.frame(qclp())) ,qclFC(),qcl())
      colnames(dat)<-c("VIP","p","FC",colnames(qcl()))
      x<-as.data.frame(dat)
      x$FC<-log(x$FC,2)
      x<-x[(x$VIP>input$vip)&(x$FC>input$hst|x$FC<(-(input$hst)))&(x$p<input$hst2)&!is.na(x$name)&(x$name!=""),]
      rownames(x)<-x$name
      x<-x[,5:ncol(x)]
      M <- cor(t(x))
      corrplot(M, method = "circle")
      
    }) 
  })
}
